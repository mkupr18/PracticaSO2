Autores: Kalyarat Asawapoom, Rupak Guni, Maria Kupriyenko
Sin mejoras realizadas ni observaciones relevantes. Es posible que algunos mensajes sean dispares a la ejecución de ejemplo.
